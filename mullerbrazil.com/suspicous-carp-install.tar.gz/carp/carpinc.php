<?php
/*
CaRP Evolution v4.0.21
Copyright (c) 2002-11 Antone Roundy

All rights reserved
This program may not be redistributed in whole or in part without written
permission from the copyright owner.

http://www.geckotribe.com/rss/carp/
Installation & Configuration Manual: http://carp.docs.geckotribe.com/
Also available as a remotely hosted service for sites that cannot run
scripts. See http://www.geckotribe.com/rss/jawfish/
*/

class RSSParser {
	var $insideitem=0;
	var $insidechannel=0;
	var $displaychannel;
	var $tag='';
	var $tagName=array();
	var $dups;
	var $ivalues;
	var $cvalues;
	var $itemcount=0;
	var $itemindex=0;
	var $top='';
	var $bottom='';
	var $body='';
	var $showit;
	var $tagpairs;
	var $filterin;
	var $filterout;
	var $filterinfield;
	var $filteroutfield;
	var $linktargets=array('',' target="_blank"',' target="_top"');
	var $channelborder;
	var $channelaorder;
	var $itemorder;
	var $formatCheck;
	var $isatom;
	var $moreitems=1;
	var $xmlbase;
	var $isinline=0;
	var $inlinetype=0;
	var $thisdata;
	var $getdata=0;
	var $encodingout='';

	function SetItemOrder($iord) {
		$this->itemorder=explode(',',preg_replace('/[^a-z0-9,]/','',strtolower($iord)));
	}

	function GetFieldValue($name,$ischannel=0) {
		global $carpcapriority,$carpiapriority,$carpcallbacks;

		$name=strtolower($name);
		$rv='';
		if ($ischannel) {
			$priority=&$carpcapriority;
			$values=&$this->cvalues;
		} else {
			$priority=&$carpiapriority;
			$values=&$this->ivalues;
		}
		if (isset($priority["$name"])) {
			foreach ($priority["$name"] as $fn => $val) {
				if ($fn{0}==':') $fn=substr($fn,strpos($fn,':',1)+1);
				if (isset($values["$fn"])) {
					$got=1;
					if (is_array($val)) {
						for ($i=1,$j=count($val);$i<$j;$i+=2) {
							if (
								(isset($val[$i+1]{0})!=isset($values[$val[$i]]{0}))||
								(isset($val[$i+1]{0})&&!preg_match($val[$i+1],$values[$val[$i]]))
							) {
								$got=0;
								break;
							}
						}
					}
					if ($got) {
						$rv=$values["$fn"];
						break;
					}
				}
			}
		}
		foreach ($carpcallbacks['getfieldvalue'] as $cb)
			if (($cb[2]=='')||($cb[2]==$name))
				$rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$ischannel?0:1,$name,$rv);
		return $rv;
	}

	function CheckFilter($lookfor,$field) {
		if (!empty($field)) {
			if (strpos(strtolower($this->GetFieldValue($field)),$lookfor)!==false) return 1;
		} else {
			if (strpos(strtolower($this->GetFieldValue('TITLE').' '.$this->GetFieldValue('DESC')),$lookfor)!==false) return 1;
		}
		return 0;
	}

	function Truncate(&$text,$max,$after,$afterlen) {
		if (($max>0)&&(CarpStrLen(preg_replace("/<.*?>/",'',$text))>$max)) {
			$j=strlen($text);
			$truncmax=$max-$afterlen;
			$isUTF8=$this->encodingout=='UTF-8';
			$out='';
			for ($i=0,$len=0;($len<$truncmax)&&($i<$j);$i++) {
				switch($text{$i}) {
				case '<':
					for ($k=$i+1;($k<$j)&&($text{$k}!='>');$k++) {
						if (($text{$k}=='"')||($text{$k}=="'")) {
							if ($m=strpos($text,$text{$k},$k+1)) $k=$m;
							else $k=$j;
						}
					}
					if (($k<$j)&&($text{$k}=='>')) $out.=substr($text,$i,$k+1-$i);
					$i=$k;
					break;
				case '&':
					if ($text{$i+1}=='#') {
						if ($text{$i+2}=='x') {
							$matchset='/[0-9]/';
							$start=$i+3;
						} else {
							$matchset='/[0-9a-fA-F]/';
							$start=$i+2;
						}
					} else {
						$matchset='/[a-zA-Z]/';
						$start=$i+1;
					}
					$valid=0;
					for ($k=$start;$k<$j;$k++) {
						$c=$text{$k};
						if (($c==';')||($c==' ')) {
							if ($k>$start) $valid=1;
							if ($c==' ') $k--;
							break;
						} else if (!preg_match($matchset,$c)) break;
					}
					if ($valid) {
						$out.=substr($text,$i,$k+1-$i);
						$i=$k;
					} else $out.='&amp;';
					$len++;
					break;
				default:
					if ($isUTF8) {
						$val=ord($text{$i});
						$bytes=($val<=0x7F)?1:(($val<=0xDF)?2:(($val<=0xEF)?3:4));
						$out.=substr($text,$i,$bytes);
						$i+=($bytes-1);
					} else $out.=$text{$i};
					$len++;
				}
			}
			$did=$i<$j;
			$text=$out.($did?$after:'');
		} else $did=0;
		return $did;
	}

	function ApplyXMLBase($url,$basedomain,$basepath) {
		if (isset($url{0})&&($url{0}=='/')) $url=$basedomain.$url;
		else if (!preg_match('#^[a-zA-Z]+://#',$url))
			$url=$basedomain.(($where=strrpos($basepath,'/'))?substr($basepath,0,$where):'')."/$url";
		return $url;
	}
	function GetXMLBase($i) {
		if ($i==-1) $i=count($this->xmlbase)-1;
		if (!preg_match('#^[a-zA-Z]+://#',$this->xmlbase[$i])) {
			if ($i&&preg_match('#^([a-zA-Z]+://[^/]+)(/.*)?$#',$this->GetXMLBase($i-1),$matches)) {
				$this->xmlbase[$i]=$this->ApplyXMLBase($this->xmlbase[$i],$matches[1],(!empty($matches[2]))?$matches[2]:'/');
			} // else error--return what we've got and hope for the best
		}
		return $this->xmlbase[$i];
	}
	function CleanURL($val) {
		global $carpconf;
		if ((isset($val{0}))&&(($val{0}=='/')||!preg_match('#^[a-zA-Z]+://#',$val))) {
			if (preg_match('#^([a-zA-Z]+://[^/]+)(/.*)?$#',$this->GetXMLBase(-1),$matches)) {
				$val=$this->ApplyXMLBase($val,$matches[1],(!empty($matches[2]))?$matches[2]:'/');
			} // else bad base URI
		}
		return preg_replace("/<[^>]*>/",'',$carpconf['html-urls']?str_replace('"','&quot;',str_replace('&','&amp;',trim($val))):trim($val));
	}

	function FormatLink($title,$link,$class,$style,$maxtitle,$atrunc,$atrunclen,$btitle,$atitle,$deftitle,$titles,$attrs) {
		global $carpcallbacks;
		global $carpconf;

		$fulltitle=$title=trim(preg_replace("/<.*?>/",'',$title));
		$didTrunc=$this->Truncate($title,$maxtitle,$atrunc,$atrunclen);
		if (!isset($title{0})) $title=$deftitle;

		$rv=$btitle.
			(isset($link{0})?(
				"<a href=\"$link\"".$this->linktargets[$carpconf['linktarget']].
				((($titles&&$didTrunc)||($titles==2))?" title=\"".str_replace('"','&quot;',$fulltitle)."\"":'')
			):(strlen($class.$style)?'<span':'')).
			(isset($class{0})?(' class="'.$class.'"'):'').
			(isset($style{0})?(' style="'.$style.'"'):'').
			((isset($link{0})&&isset($attrs{0}))?" $attrs ":'').
			(strlen($link.$class.$style)?'>':'').
			$title.
			(isset($link{0})?'</a>':(strlen($class.$style)?'</span>':'')).
			$atitle.$carpconf['afield'];
		foreach ($carpcallbacks['outputfield'] as $cb)
			if (($cb[2]=='')||($cb[2]=='title')||($cb[2]=='link'))
				$rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$this->insideitem,(isset($link{0})?'link':'title'),
					$this->itemindex,$this->itemcount,$rv);
		return $rv;
	}

	function FormatImage($url,$link,$w,$h,$alt,$ci) {
		global $carpcallbacks;
		global $carpconf;
		if (isset($url{0})) {
			if ($carpconf["set$ci".'imagew']) {
				if ($carpconf["set$ci".'imageh']) {
					$w=$carpconf["set$ci".'imagew'];
					$h=$carpconf["set$ci".'imageh'];
				} else {
					if ($w) {
						$sr=$carpconf["set$ci".'imagew']/$w;
						$h=round($h*$sr);
					}
					$w=$carpconf["set$ci".'imagew'];
				}
			} else if ($carpconf["set$ci".'imageh']) {
				if ($h) {
					$sr=$carpconf["set$ci".'imageh']/$h;
					$w=round($w*$sr);
				}
				$h=$carpconf["set$ci".'imageh'];
			} else if ($carpconf["max$ci".'imagew']&&($w>$carpconf["max$ci".'imagew'])) {
				$wr=($carpconf["max$ci".'imagew']/$w);
				if ($carpconf["max$ci".'imageh']) {
					$hr=($h>$carpconf["max$ci".'imageh'])?($carpconf["max$ci".'imageh']/$h):1;
					$sr=min($wr,$hr);
					$w=round($w*$sr);
					$h=round($h*$sr);
				} else {
					$w=$carpconf["max$ci".'imagew'];
					$h=round($h*$wr);
				}
			} else if ($carpconf["max$ci".'imageh']&&($h>$carpconf["max$ci".'imageh'])) {
				$sr=($carpconf["max$ci".'imageh']/$h);
				$h=$carpconf["max$ci".'imageh'];
				$w=round($w*$sr);
			}
			if (!$w&&$carpconf["def$ci".'imagew']) $w=$carpconf["def$ci".'imagew'];
			if (!$h&&$carpconf["def$ci".'imageh']) $h=$carpconf["def$ci".'imageh'];
			$rv=($carpconf["b$ci".'image'].
				(isset($link{0})?('<a href="'.$link.'"'.$this->linktargets[$carpconf['linktarget']].'>'):'').
				'<img src="'.$url.'"'.($w?" width=\"$w\"":'').($h?" height=\"$h\"":'').' border="0"'.(isset($alt{0})?(' alt="'.str_replace('"','&quot;',$alt).'"'):'').' />'.
				(isset($link{0})?'</a>':'').
				$carpconf["a$ci".'image'].$carpconf['afield']);
		} else $rv='';
		foreach ($carpcallbacks['outputfield'] as $cb)
			if (($cb[2]=='')||($cb[2]=='image'))
				$rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),($ci=='i'),'image',$this->itemindex,$this->itemcount,$rv);
		return $rv;
	}

	function FormatDate($val,$ci) {
		global $carpcallbacks;
		global $carpconf;
		$rv=($val>0)?($carpconf["b$ci".'date'].($carpconf[$ci.'useidate']?
				strftime($carpconf[$ci.'idateformat'],$val):
				date($carpconf[$ci.'dateformat'],$val)
			).$carpconf["a$ci".'date'].$carpconf['afield']):'';
		foreach ($carpcallbacks['outputfield'] as $cb)
			if (($cb[2]=='')||($cb[2]=='date'))
				$rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),($ci=='i'),'date',$this->itemindex,$this->itemcount,$rv);
		return $rv;
	}

	function FormatSimpleField($val,$ci,$name,$fixamp=0) {
		global $carpcallbacks;
		global $carpconf;
		if ($fixamp) $val=str_replace('&','&amp;',$val);
		$rv=isset($val{0})?($carpconf["b$ci$name"].$val.$carpconf["a$ci$name"].$carpconf['afield']):'';
		foreach ($carpcallbacks['outputfield'] as $cb)
			if (($cb[2]=='')||($cb[2]==$name))
				$rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),($ci=='i'),$name,$this->itemindex,$this->itemcount,$rv);
		return $rv;
	}

	function ListOpenTags(&$input) {
		if (preg_match_all("#<(/?\w+).*?>#",$input,$matches)) {
			$rv=$matches[1];
			for ($i=0;$i<count($rv);$i++) {
				$tag=$rv[$i]=strtolower($rv[$i]);
				if ($isClose=($tag{0}=='/')) $tag=substr($tag,1);
				if (!isset($this->tagpairs["$tag"])) {
					array_splice($rv,$i,1);
					$i--;
				} else if ($isClose) {
					array_splice($rv,$i,1);
					$i--;
					for ($j=$i;$j>=0;$j--) {
						if ($rv[$j]==$tag) {
							array_splice($rv,$j,1);
							$i--;
							break;
						}
					}
				}
			}
		} else $rv=array();
		return $rv;
	}

	function ProcessDescription($description,$maxdesc,$atrunc,$atrunclen) {
		global $carpconf;
		if (isset($description{0})) {
			if (isset($carpconf['desctags']{0})) {
				$adddesc=trim(preg_replace("#<(?!".$carpconf['desctags'].")(.*?)>#is",
					($carpconf['removebadtags']?'':"&lt;\\1\\2&gt;"),$description));
				$adddesc=preg_replace('/(<[^>]*?)\bon[a-z]+\s*=\s*("[^"]*"|\'[^\']*\')(.*?>)/i',"\\1\\3",$adddesc);
			} else $adddesc=trim(preg_replace("#<(.*?)>#s",($carpconf['removebadtags']?'':"&lt;\\1&gt;"),$description));
			$didTrunc=$this->Truncate($adddesc,$maxdesc,'',$atrunclen);

			$opentags=$this->ListOpenTags($adddesc);
			if (isset($adddesc{0})) {
				if ($didTrunc) $adddesc.=$atrunc;
				for ($i=count($opentags)-1;$i>=0;$i--) $adddesc.="</$opentags[$i]>";
			}
		} else $adddesc='';
		return $adddesc;
	}

	function FormatDescription($description,$maxdesc,$b,$a,$atrunc,$atrunclen) {
		global $carpcallbacks;
		global $carpconf;
		$adddesc=$this->ProcessDescription($description,$maxdesc,$atrunc,$atrunclen);
		if (isset($adddesc{0})) $adddesc="$b$adddesc$a".$carpconf['afield'];
		foreach ($carpcallbacks['outputfield'] as $cb)
			if (($cb[2]=='')||($cb[2]=='desc'))
				$adddesc=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$this->insideitem,'desc',$this->itemindex,$this->itemcount,$adddesc);
		return $adddesc;
	}

	function XMLFormatError($show=0) {
		switch ($this->formatCheck) {
		case -1: $rv='Unknown RDF-based format or non-standard RSS element name prefix.'; break;
		case -11:
		case -12: $rv='Unknown feed format.'; break;
		case -20: $rv='This appears to be an HTML webpage, not a feed.'; break;
		case -100:
		case -101: $rv='Unknown document format.'; break;
		default: $rv='';
		}
		if (isset($rv{0})&&$show) CarpError($rv,'unknown-format');
		return " - $rv";
	}

	function CheckFormat($tagName,&$attrs) {
		if (strpos($tagName,':')) {
			list($prefix,$name)=explode(':',$tagName);
			switch ($name) {
			case 'RDF':
				foreach ($attrs as $k=>$v) {
					if ((strpos($k,'XMLNS')===0)&&(strpos($v,'http://purl.org/rss/')===0)) {
						$this->formatCheck=1;
						break;
					}
				}
				if (!$this->formatCheck) $this->formatCheck=-1;
				break;
			case 'feed':
				switch ($attrs["XMLNS:$prefix"]) {
				case 'http://www.w3.org/2005/Atom': $this->formatCheck=10; break;
				case 'http://purl.org/atom/ns#': $this->formatCheck=3; break;
				default: $this->formatCheck=-11;
				}
				break;
			default: $this->formatCheck=-100;
			}
		} else {
			switch($tagName) {
			case 'RSS': $this->formatCheck=2; break;
			case 'HTML': $this->formatCheck=-20; break;
			case 'FEED':
				switch ($attrs["XMLNS"]) {
				case 'http://www.w3.org/2005/Atom': $this->formatCheck=10; break;
				case 'http://purl.org/atom/ns#': $this->formatCheck=3; break;
				default: $this->formatCheck=-12;
				}
				break;
			default: $this->formatCheck=-101;
			}
		}
		switch($this->formatCheck) {
		case 3: case 10: $this->isatom=1; break;
		default: $this->isatom=0;
		}
	}

	function MapPrefix(&$tagName,&$attrs) {
		global $carpconf;
		foreach ($carpconf['prefix-map'] as $k=>$v) {
			if (isset($v{0})) $v="$v:";
			$tagName=preg_replace("/^$k:/",$v,$tagName);
			if (is_array($attrs)) {
				$newattrs=array();
				foreach ($attrs as $ak=>$av) {
					if (($nak=preg_replace("/^$k:/","$v:",$ak))!=$ak) $newattrs[$nak]=$av;
					else $newattrs[$ak]=$av;
				}
				$attrs=$newattrs;
			}
		}
	}

	function startElement($parser,$tagName,$attrs) {
		global $carpcallbacks;
		global $carpconf;
		global $carpcafields,$carpiafields,$carpurlattrs,$carpinline,$carprenametag;

		if (isset($attrs['XML:BASE'])) $this->xmlbase[]=$attrs['XML:BASE'];
		else $this->xmlbase[]='';

		if ($carpconf['strip-xhtml-prefixes']) {
			foreach ($attrs as $k=>$v)
				if ((substr($k,0,6)=='XMLNS:')&&($v=='http://www.w3.org/1999/xhtml')) {
					list($junk,$ns)=explode(':',$k,2);
					$carpconf['prefix-map'][$ns]='';
				}
		}

		$this->MapPrefix($tagName,$attrs);

		if ((!$this->isinline)&&isset($carprenametag[$tagName])) {
			foreach ($carprenametag[$tagName] as $k=>$v) {
				$is_match=1;
				for ($i=0,$j=count($v);$i<$j;$i+=2) {
					$invert=(isset($v[$i+1]{0})&&($v[$i+1]{0}=='^'));
					if (!(isset($attrs[$v[$i]])&&(preg_match($invert?substr($v[$i+1],1):$v[$i+1],$attrs[$v[$i]])!=$invert))) {
						$is_match=0;
						break;
					}
				}
				if ($is_match) {
					$tagName=$k;
					break;
				}
			}
		}
		array_unshift($this->tagName,$tagName);

		$this->tag.=(isset($this->tag{0})?'^':'').$tagName;

		if (isset($carpurlattrs[$tagName])) {
			foreach ($carpurlattrs[$tagName] as $attr) if (isset($attrs[$attr]))
				$attrs[$attr]=$this->CleanURL($attrs[$attr]);
		}

		if (!$this->formatCheck) $this->CheckFormat($tagName,$attrs);

		if ($this->insideitem) {
			$f=&$carpiafields;
			$vals=&$this->ivalues;
		} else {
			$f=$carpcafields;
			$vals=&$this->cvalues;
		}

		if (!$this->isinline) {
			$this->getdata=0;
			if (isset($f[$this->tag])) {
				if (!isset($vals[$this->tag])) {
					$vals[$this->tag]='';
					$this->thisdata=&$vals[$this->tag];
					$this->getdata=1;
				}
			}
			if ($this->isatom&&$this->getdata&&in_array($tagName,$carpinline)) {
				$this->isinline=1;
				switch($this->formatCheck) {
				case 3:
					if (isset($attrs['MODE'])&&($attrs['MODE']=='base64')) $this->inlinetype+=1;
					if (!isset($attrs['TYPE'])||($attrs['TYPE']=='text/plain')) $this->inlinetype+=2;
					break;
				case 10:
					if ((!isset($attrs['TYPE']))||(!isset($attrs['TYPE']{0}))||($attrs['TYPE']=='text')||($attrs['TYPE']=='text/plain'))
						$this->inlinetype=1;
					else if (isset($attrs['TYPE'])&&(($attrs['TYPE']=='xhtml')||($attrs['TYPE']=='application/xhtml+xml'))) $this->inlinetype=2;
					else if (isset($attrs['TYPE'])&&(($attrs['TYPE']=='html')||($attrs['TYPE']=='text/html'))) $this->inlinetype=3;
					break;
				}
			}
		}
		if ($this->isinline) $this->isinline++;
		if ($this->isinline>2) {
			$this->thisdata.='<'.strtolower($tagName);
			foreach ($attrs as $k=>$v) $this->thisdata.=" $k=\"".strtr($v,array('&'=>'&amp;','"'=>'&quot;')).'"';
			$this->thisdata.='>';
		} else {
			foreach ($carpcallbacks['startelement'] as $cb)
				if (($cb[2]=='')||preg_match("/$cb[2]/",$this->tag))
					call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$this->insideitem,$this->tag,$attrs);
			if ($this->insidechannel) $this->insidechannel++;
			if ($this->insideitem) $this->insideitem++;
			if (($tagName=="ITEM")||($tagName=="ENTRY")) {
				$this->insideitem=1;
				$this->ivalues=array();
				$this->tag='';
			} else if (($tagName=="CHANNEL")||($tagName=="FEED")) {
				$this->insidechannel=1;
				$this->cvalues=array();
				$this->tag='';
			}
			else {
				$haveSome=0;
				foreach($attrs as $key => $val)
					if (isset($f[$this->tag."^$key"])&&isset($vals[$this->tag."^$key"])) {
						$haveSome=1;
						break;
					}
				if (!$haveSome) foreach($attrs as $key => $val)
					if (isset($f[$this->tag."^$key"])&&!isset($vals[$this->tag."^$key"])) $vals[$this->tag."^$key"]=$val;
			}
		}
	}

	function ProcessDataField($name,$is_channel=0) {
		global $carpcallbacks;
		global $carpconf;
		$rv='';
		if ($is_channel) {
			switch ($name) {
			case 'link':
			case 'title':
				$rv.=$this->FormatLink($this->GetFieldValue('TITLE',1),(($name=='link')?$this->GetFieldValue('URL',1):''),
				$carpconf['clinkclass'],$carpconf['clinkstyle'],$carpconf['maxctitle'],$carpconf['atruncctitle'],$carpconf['atruncctitlelen'],
				$carpconf['bctitle'],$carpconf['actitle'],'',$carpconf['clinktitles'],$carpconf['clink_attrs']); break;
			case 'url': $rv.=$this->FormatSimpleField($this->GetFieldValue('URL',1),'c','url',1); break;
			case 'desc':
				$rv.=$this->FormatDescription($this->GetFieldValue('DESC',1),
					$carpconf['maxcdesc'],$carpconf['bcdesc'],$carpconf['acdesc'],$carpconf['atrunccdesc'],$carpconf['atrunccdesclen']);
				break;
			case 'date': $rv.=$this->FormatDate(CarpDecodeDate($this->GetFieldValue('DATE',1)),'c'); break;
			case 'image': $rv.=$this->FormatImage($this->GetFieldValue('IMAGEURL',1),$this->GetFieldValue('IMAGELINK',1),$this->GetFieldValue('IMAGEWIDTH',1),$this->GetFieldValue('IMAGEHEIGHT',1),$this->GetFieldValue('IMAGEALT',1),'c'); break;
			default:
				$rvd='';
				foreach ($carpcallbacks['handlefield'] as $cb)
					if ($cb[2]==$name)
						$rvd=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),1,$name,0,$this->cvalues,$rvd);
				$rv.=$rvd;

			}
		} else {
			switch ($name) {
			case 'link':
			case 'title':
				$rv.=$this->FormatLink($this->GetFieldValue('TITLE'),(($name=='link')?$this->GetFieldValue('URL'):''),
				$carpconf['ilinkclass'],$carpconf['ilinkstyle'],$carpconf['maxititle'],$carpconf['atruncititle'],$carpconf['atruncititlelen'],
				$carpconf['bilink'],$carpconf['ailink'],$carpconf['defaultititle'],$carpconf['ilinktitles'],$carpconf['ilink_attrs']); break;
			case 'url': $rv.=$this->FormatSimpleField($this->GetFieldValue('URL'),'i','url',1); break;
			case 'author': $rv.=$this->FormatSimpleField($this->GetFieldValue('AUTHOR'),'i','author'); break;
			case 'date':
				$rv.=$this->FormatDate(CarpDecodeDate($this->GetFieldValue('DATE')),'i'); break;
			case 'podcast': $rv.=$this->FormatSimpleField($this->GetFieldValue('PODCAST'),'i','podcast');
				break;
			case 'image': $rv.=$this->FormatImage($this->GetFieldValue('IMAGEURL'),$this->GetFieldValue('IMAGELINK'),$this->GetFieldValue('IMAGEWIDTH'),$this->GetFieldValue('IMAGEHEIGHT'),$this->GetFieldValue('IMAGEALT'),'i'); break;
			case 'desc':
				$rv.=$this->FormatDescription($this->GetFieldValue('DESC'),
					$carpconf['maxidesc'],$carpconf['bidesc'],$carpconf['aidesc'],$carpconf['atruncidesc'],$carpconf['atruncidesclen']);
				break;
			default:
				$rvd='';
				foreach ($carpcallbacks['handlefield'] as $cb)
					if ($cb[2]==$name)
						$rvd=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),1,$name,$this->itemindex,$this->itemcount,$this->ivalues,$rvd);
				$rv.=$rvd;
			}
		}
		return $rv;
	}

	function endElement($parser,$tagName) {
		global $carpconf;
		global $carpurltags;
		global $carpcallbacks;

		$tagName=array_shift($this->tagName);

		$empty='';
		$this->MapPrefix($tagName,$empty);

		if (in_array($this->tag,$carpurltags)) $this->thisdata=$this->CleanURL($this->thisdata);

		array_pop($this->xmlbase);

		if ($this->isinline) {
			$this->isinline--;
			if ($this->isinline==1) $this->isinline=0;
			else {
				$this->thisdata.='</'.strtolower($tagName).'>';
				$this->tag=substr($this->tag,0,strrpos($this->tag,'^'));
			}
		}
		if (!$this->isinline) {
			if ($this->inlinetype) {
				switch ($this->formatCheck) {
				case 3:
					if ($this->inlinetype&1) $this->thisdata=base64decode($this->thisdata);
					if ($this->inlinetype&2) $this->thisdata=strtr($this->thisdata,array('&'=>'&amp;','<'=>'&lt;','>'=>'&gt;'));
					break;
				case 10:
					switch ($this->inlinetype) {
					case 1: $this->thisdata=strtr($this->thisdata,array('&'=>'&amp;','<'=>'&lt;','>'=>'&gt;')); break;
					case 2:
						$start=strpos($this->thisdata,'>')+1;
						$this->thisdata=substr($this->thisdata,$start,strrpos($this->thisdata,'<')-$start);
						break;
					case 3: break;
					default: $this->thisdata='';
					}
					break;
				}
				$this->inlinetype=0;
			}
			foreach ($carpcallbacks['endelement'] as $cb)
				if (($cb[2]=='')||preg_match("/$cb[2]/",$this->tag))
					call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$this->insideitem,$this->tag);
			$this->getdata=0;
			$this->tag=substr($this->tag,0,strrpos($this->tag,'^'));
			if (($tagName=="ITEM")||($tagName=="ENTRY")) {
				if ($this->moreitems&&($this->itemcount<$carpconf['maxitems'])) {
					$filterblock=0;

					if (count($this->filterin)) {
						$filterblock=1;
						for ($i=count($this->filterin)-1;$i>=0;$i--) {
							if ($this->CheckFilter($this->filterin[$i],$this->filterinfield[$i])) {
								$filterblock=0;
								break;
							}
						}
					}
					if (count($this->filterout)&&!$filterblock) {
						for ($i=count($this->filterout)-1;$i>=0;$i--) {
							if ($this->CheckFilter($this->filterout[$i],$this->filteroutfield[$i])) {
								$filterblock=1;
								break;
							}
						}
					}
					if (!$filterblock) foreach ($carpcallbacks['displayitem'] as $cb)
						if (($rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$this->itemindex,$this->itemcount))<=0) {
							$filterblock=1;
							if ($rv<0) $this->moreitems=0;
							break;
						}
					if (!$filterblock) {
						$fulltitle=trim($this->GetFieldValue('TITLE'));
						$skipit=0;
						if ($carpconf['skipdups']) {
							if (!isset($this->dups["$fulltitle"])) $this->dups["$fulltitle"]=1;
							else $skipit=1;
						}
						if (!$skipit) {
							$carpconf['items-shown']++;
							$thisitem=$carpconf['bi'];

							$pubdate=CarpDecodeDate($this->GetFieldValue('DATE'));

							for ($ioi=0;$ioi<count($this->itemorder);$ioi++) $thisitem.=$this->ProcessDataField($this->itemorder[$ioi]);
							$thisitem.=$carpconf['ai'];
							$this->itemcount++;
							if ($this->showit) $this->body.=$thisitem.$carpconf['aitem'];
							else $this->body.=(
									$pubdate?($pubdate+($carpconf['timeoffset']*60)):(($cdate=CarpDecodeDate($this->GetFieldValue('DATE',1)))?
										($cdate+($carpconf['timeoffset']*60)-$this->itemcount):(($carpconf['lastmodified']>0)?($carpconf['lastmodified']-$this->itemcount):0)
									)
								).
								':'.preg_replace("/[\r\n]/",' ',(str_replace(":",'_',$fulltitle).':'.$thisitem))."\n";
						}
					}
				}
				$this->insideitem=0;
				$this->itemindex++;
			} else if (($tagName=="CHANNEL")||($tagName=="FEED")) {
				$this->displaychannel=1;
				foreach ($carpcallbacks['displaychannel'] as $cb)
					if (($rv=call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1])))<=0) {
						$this->displaychannel=0;
						if ($rv<0) $this->itemcount=$carpconf['maxitems'];
					}
				$this->insidechannel=0;
			}
			if ($this->insidechannel) $this->insidechannel--;
			if ($this->insideitem) $this->insideitem--;
		}
	}

	function DoEndChannel(&$data,&$order,&$b,&$a) {
		global $carpconf;
		for ($coi=0;$coi<count($order);$coi++) $data.=$this->ProcessDataField($order[$coi],1);
		if (isset($data{0})) $data=$b.$data.$a;
		if (!$this->showit) $data=preg_replace("/\n/",' ',$data);
	}

	function characterData($parser,$data) {
		global $carpconf,$carpcafields,$carpiafields;
		global $carpcallbacks;

		if ($this->insideitem&&($this->itemcount==$carpconf['maxitems'])) return;

		foreach ($carpcallbacks['characterdata'] as $cb)
			if (($cb[2]=='')||preg_match("/$cb[2]/",$this->tag))
				call_user_func(($cb[0]==='')?$cb[1]:array($cb[0],$cb[1]),$this->insideitem,$this->tag,$data);
		if ($this->getdata) $this->thisdata.=$data;
	}

	function PrepTagPairs($tags) {
		$this->tagpairs=$findpairs=array();
		$temptags=explode('|',strtolower(preg_replace("/\\\\b/",'',$tags)));
		for ($i=count($temptags)-1;$i>=0;$i--) {
			$tag=$temptags[$i];
			if (strcmp(substr($tag,0,1),'/')) {
				$searchpre='/';
				$baretag=$tag;
			} else {
				$searchpre='';
				$baretag=substr($tag,1);
			}
			if (isset($findpairs["$searchpre$baretag"])) {
				$this->tagpairs["$baretag"]=1;
				$findpairs["$baretag"]=$findpairs["/$baretag"]=2;
			} else $findpairs["$tag"]='1';
		}
	}
}

function CarpDecodeDate($val) {
	global $carpconf;
	if (isset($val{0})) {
		if (
			(($rv=strtotime($val))==-1)&&
			(($rv=strtotime(preg_replace("/([0-9]+\-[0-9]+\-[0-9]+)T([0-9:]*)(\\.[0-9]*)?(?:Z|([-+][0-9]{1,2}):([0-9]{2}))/","$1 $2 $4$5",$val)))==-1)
		) {
			$thisyear=date('Y');
			if (($rv=strtotime(preg_replace("/( [0-9]{1,2}:[0-9]{2})/",", $thisyear $1",$val)))==-1) $rv=0;
		}
	} else $rv=0;
	return $rv?($rv+($carpconf['timeoffset']*60)):0;
}

function OpenRSSFeed($url) {
	global $carpconf,$carpversion,$CarpRedirs;
	$carpconf['statuscode']=-1;

	if (strtolower(substr($url,0,7))=='feed://') $url='http://'.substr($url,7);
	$carpconf['final_url']=$url;
	$carpconf['lastmodified']='';
	if (preg_match('#^https?://#i',$url)) {
		if (isset($carpconf['proxyserver']{0})) {
			$urlparts=parse_url($carpconf['proxyserver']);
			$therest=$url;
			$scheme='';
		} else {
			$urlparts=parse_url($url);
			$therest=$urlparts['path'].(isset($urlparts['query'])?('?'.$urlparts['query']):'');
			$scheme=(strtolower($urlparts['scheme'])=='https')?'ssl://':'';
		}
		$domain=$urlparts['host'];
		$port=empty($urlparts['port'])?(empty($scheme)?80:443):$urlparts['port'];
		$fp=fsockopen($scheme.$domain,$port,$errno,$errstr,$carpconf['timeout']);
		if ($fp) {
			fputs($fp,"GET $therest HTTP/1.0\r\n".
				($carpconf['sendhost']?"Host: $domain\r\n":'').
				(isset($carpconf['proxyauth']{0})?('Proxy-Authorization: Basic '.base64_encode($carpconf['proxyauth'])."\r\n"):'').
				(isset($carpconf['basicauth']{0})?('Authorization: Basic '.base64_encode($carpconf['basicauth'])."\r\n"):'').
				(isset($carpconf['accept']{0})?('Accept: '.$carpconf['accept']."\r\n"):'').
				"User-Agent: CaRP/$carpversion\r\n".
				"Connection: close\r\n\r\n");
			if ($header=fgets($fp,1000)) {
				$temp=explode(' ',$header);
				if (count($temp)<2) {
					fclose($fp);
					return 0;
				}
				$carpconf['statuscode']=$temp[1];
				if ($temp[1]>303) {
					fclose($fp);
					return 0;
				}
			}
			while ((!feof($fp))&&preg_match("/[^\r\n]/",$header=fgets($fp,1000))) {
				if (strtolower(substr($header,0,9))=='location:') {
					fclose($fp);
					if (count($CarpRedirs)<$carpconf['maxredir']) {
						$loc=trim(substr($header,9));
						if (!preg_match('#^https?://#i',$loc)) {
							if (isset($carpconf['proxyserver']{0})) {
								$redirparts=parse_url($url);
								$loc=$redirparts['scheme'].'://'.$redirparts['host'].(isset($redirparts['port'])?(':'.$redirparts['port']):'').$loc;
							} else $loc="http://$domain".(($port==80)?'':":$port").$loc;
						}
						for ($i=count($CarpRedirs)-1;$i>=0;$i--) if (!strcmp($loc,$CarpRedirs[$i])) {
							CarpError('Redirection loop detected. Giving up.','redirection-loop');
							return 0;
						}
						$CarpRedirs[count($CarpRedirs)]=$loc;
						return OpenRSSFeed($loc);
					} else {
						CarpError('Too many redirects. Giving up.','redirection-too-many');
						return 0;
					}
				} else if (strtolower(substr($header,0,14))=='last-modified:')
					$carpconf['lastmodified']=CarpDecodeDate(substr($header,14));
			}
		} else CarpError("$errstr ($errno)",'connection-failed');
	} else if ($fp=fopen($url,'r')) {
		if ($stat=fstat($fp)) $carpconf['lastmodified']=$stat['mtime'];
	} else CarpError("Failed to open file: $url",'local-file-open-failed');
	return $fp;
}

function CarpCacheUpdatedMysql() {
	global $carpconf;
	$rv=-1;
	CarpCacheMysqlConnect();
	if (CarpParseMySQLPath($carpconf['cachefile'],$which,$key)) {
		if ($r=CarpMySQLQuery('select updated from '.$carpconf['mysql-database-name'].$carpconf['mysql-tables'][$which].' where id="'.addslashes($key).'"')) {
			if (mysql_num_rows($r)) $rv=mysql_result($r,0);
			else $rv=0;
			mysql_free_result($r);
		} else CarpError('Database error attempting to check cache update time.','database-error');
	} else CarpError('Invalid cache identifier checking cache update time.','cache-not-found');
	return $rv;
}

function CarpCacheUpdatedFile($f) {
	global $carpconf;
	if ($s=fstat($f)) $rv=$s['mtime'];
	else {
		$rv=-1;
		CarpError('Can\'t stat cache file.','cache-file-access');
		fclose($f);
	}
	return $rv;
}

function CarpSaveCache($f,$data) {
	global $carpconf;
	switch($carpconf['cache-method']) {
	case 'mysql': if (CarpParseMySQLPath($carpconf['cachefile'],$which,$key)) {
			if (!CarpMySQLQuery('update '.$carpconf['mysql-database-name'].$carpconf['mysql-tables'][$which].' set updated='.time().',cache="'.addslashes($data).'" where id="'.addslashes($key).'"'))
				CarpError('Database error attempting to cache formatted data.','database-error');
			} else CarpError('Invalid cache indentifier saving cache.','cache-not-found');
		break;
	default: fwrite($f,$data); break;
	}
}

function CarpOpenCacheWriteMySQL() {
	global $carpconf;
	CarpCacheMysqlConnect();
	$rv=0;
	if (($a=CarpCacheUpdatedMysql())>=0) {
		if ($r=CarpMySQLQuery('select GET_LOCK("'.$carpconf['cachefile'].'",'.$carpconf['mysql-lock-timeout'].')')) {
			if (mysql_result($r,0)+0) {
				$b=CarpCacheUpdatedMysql();
				if ($a!=$b) CarpMySQLQuery('select RELEASE_LOCK("'.$carpconf['cachefile'].'")');
				else {
					CarpParseMySQLPath($carpconf['cachefile'],$rv,$key);
					$rv++;
					if (!$b) CarpTouchCache($carpconf['cachefile']);
				}
			}
		} else $rv=-1;
	} else $rv=-1;
	if ($rv==-1) CarpError('Failed to access database cache record.','cache-prepare-failed');
	return $rv;
}

function CarpOpenCacheWriteFile() {
	global $carpconf;
	$rv=0;
	if (!file_exists($carpconf['cachefile'])) touch($carpconf['cachefile']);
	if ($f=fopen($carpconf['cachefile'],'r+')) {
		if ($a=CarpCacheUpdatedFile($f)) {
			flock($f,LOCK_EX); // ignore result--doesn't work for all systems and situations
			clearstatcache();
			if ($b=CarpCacheUpdatedFile($f)) {
				if ($a!=$b) {
					flock($f,LOCK_UN);
					fclose($f);
				} else $rv=$f;
			} else $rv=-1;
		} else $rv=-1;
	} else $rv=-1;
	if ($rv==-1) {
		CarpError("Can't open cache file.",'cache-prepare-failed');
		if ($f) fclose($f);
	}
	return $rv;
}

function OpenCacheWrite() {
	switch($GLOBALS['carpconf']['cache-method']) {
	case 'mysql': $rv=CarpOpenCacheWriteMySQL(); break;
	default: $rv=CarpOpenCacheWriteFile(); break;
	}
	return $rv;
}

function CloseCacheWrite($f) {
	global $carpconf;
	switch($carpconf['cache-method']) {
	case 'mysql': CarpMySQLQuery('select RELEASE_LOCK("'.$carpconf['cachefile'].'")'); break;
	default: ftruncate($f,ftell($f));
		fflush($f);
		flock($f,LOCK_UN);
		fclose($f);
	}
	$carpconf['mtime']=time();
}

function DoCacheRSSFeed($data,$cache='') {
	global $carpconf;
	if (isset($cache{0})) {
		$savecache=$carpconf['cachefile'];
		$carpconf['cachefile']=$cache;
	}
	if (($outf=OpenCacheWrite())>0) {
		switch($carpconf['cache-method']) {
		case 'mysql':
			CarpParseMySQLPath($carpconf['cachefile'],$which,$key);
			if (!CarpMySQLQuery('update '.$carpconf['mysql-database-name'].$carpconf['mysql-tables'][$which].' set updated='.time().',cache="'.addslashes($data).
				'" where id="'.$key.'"')
			) CarpError('Database error attempting to cache feed.','database-error');
			break;
		default: fwrite($outf,$data);
		}
		CloseCacheWrite($outf);
	}
	if (isset($cache{0})) $carpconf['cachefile']=$savecache;
}

function CacheRSSFeed($url) {
	global $carpconf,$CarpRedirs;
	$d='';
	$CarpRedirs=array();
	if (substr($url,0,8)=='grouper:') $d=GrouperGetCache(substr($url,8))?$GLOBALS['grouperrawdata']:'';
	else if ($f=OpenRSSFeed($url)) {
		while (!feof($f)) if (($l=fread($f,4000))!==false) $d.=$l;
		fclose($f);
	} else CarpError('Can\'t open remote newsfeed ['.$carpconf['statuscode'].'].','feed-access-failed',0);
	if (isset($d{0})) DoCacheRSSFeed($d);
}

function CarpReadData($fp) {
	global $carpconf;
	return $carpconf['fixentities']?
		preg_replace("/&(?!lt|gt|amp|apos|quot|#[0-9]+|#x[0-9a-f]+)(.*\b)/is","&amp;\\1\\2",preg_replace("/\\x00/",'',fread($fp,4096))):
		preg_replace("/\\x00/",'',fread($fp,4096));
}

function CarpStrLen($s) {
	if (strtoupper($GLOBALS['carpconf']['encodingout'])=='UTF-8') {
		for ($i=$len=0,$j=strlen($s);$i<$j;$len++) {
			$val=ord($s{$i});
			$i+=($val<=0x7F)?1:(($val<=0xDF)?2:(($val<=0xEF)?3:4));
		}
	} else $len=strlen($s);
	return $len;
}

function CarpCleanInput(&$data,$encodingin) {
	switch($encodingin) {
	case 'UTF-8':
		$data=preg_replace('/(\r|\n|\t|[\x20-\x7E]|[\xC0-\xDF][\x80-\xBF]|[\xE0-\xEF][\x80-\xBF]{2}|[\xF0-\xF7][\x80-\xBF]{3})|./','$1',$data);
		break;
	case 'ISO-8859-1':
		$data=preg_replace('/(\r|\n|\t|[\x20-\x7E]|[\xA0-\xFF])|./','$1',$data);
		break;
	}
}

function GetRSSFeed($url,$cache,$showit) {
	global $carpconf,$CarpRedirs;

	MyForceConf();

	$carpconf['desctags']=preg_replace("/(^\\|)|(\\|$)/",'',preg_replace("/\\|+/","|",preg_replace('#/?('.
		str_replace(',','|',carp_banned_tags).')#i','',$carpconf['descriptiontags'])));
	if (!empty($carpconf['desctags'])) $carpconf['desctags']=str_replace('|','\b|',$carpconf['desctags']).'\b';

	$carpconf['cuseidate']=isset($carpconf['cidateformat']{0});
	$carpconf['iuseidate']=isset($carpconf['iidateformat']{0});
	$carpconf['atruncititlelen']=CarpStrLen($carpconf['atruncititle']);
	$carpconf['atruncctitlelen']=CarpStrLen($carpconf['atruncctitle']);
	$carpconf['atruncidesclen']=CarpStrLen($carpconf['atruncidesc']);
	$carpconf['atrunccdesclen']=CarpStrLen($carpconf['atrunccdesc']);

	$rss_parser=new RSSParser();
	$carpconf['rssparser']=&$rss_parser;
	CarpTranscodePrep();
	if ($carpconf['skipdups']) $rss_parser->dups=array();
	$rss_parser->showit=$showit;
	$rss_parser->channelborder=explode(',',preg_replace('/[^a-z0-9,]/','',strtolower($carpconf['cborder'])));
	$rss_parser->channelaorder=explode(',',preg_replace('/[^a-z0-9,]/','',strtolower($carpconf['caorder'])));
	$rss_parser->SetItemOrder($carpconf['iorder']);
	$rss_parser->formatCheck=0;

	if (preg_match("/[^0-9]/",$carpconf['linktarget'])) $rss_parser->linktargets[$carpconf['linktarget']]=' target="'.$carpconf['linktarget'].'"';
	$rss_parser->filterinfield=array();
	if (isset($carpconf['filterin']{0})) {
		$rss_parser->filterin=explode('|',strtolower($carpconf['filterin']));
		for ($i=count($rss_parser->filterin)-1;$i>=0;$i--) {
			if (strpos($rss_parser->filterin[$i],':')!==false)
				list($rss_parser->filterinfield[$i],$rss_parser->filterin[$i])=explode(':',$rss_parser->filterin[$i],2);
			else $rss_parser->filterinfield[$i]='';
		}
	} else $rss_parser->filterin=array();
	$rss_parser->filteroutfield=array();
	if (isset($carpconf['filterout']{0})) {
		$rss_parser->filterout=explode('|',strtolower($carpconf['filterout']));
		for ($i=count($rss_parser->filterout)-1;$i>=0;$i--) {
			if (strpos($rss_parser->filterout[$i],':')!==false)
				list($rss_parser->filteroutfield[$i],$rss_parser->filterout[$i])=explode(':',$rss_parser->filterout[$i],2);
			else $rss_parser->filteroutfield[$i]='';
		}
	} else $rss_parser->filterout=array();

	$fromfp=0;
	if (substr($url,0,6)=='mysql:') $data=CarpGetCache($url);
	else if (substr($url,0,8)=='grouper:') $data=GrouperGetCache(substr($url,8))?$GLOBALS['grouperrawdata']:'';
	else $fromfp=1;
	$CarpRedirs=array();
	if ((!$fromfp)||($fp=OpenRSSFeed($url))) {
		if ($fromfp) $data=CarpReadData($fp);
		$data=preg_replace('/^[^<]+/','',$data);
		$encodings_internal=array('ISO-8859-1','UTF-8','US-ASCII');
		$transcodeout=(isset($carpconf['encodingout']{0})&&!in_array(strtoupper($carpconf['encodingout']),$encodings_internal))?1:0;
		if (isset($carpconf['encodingin']{0})) $encodingin=$carpconf['encodingin'];
		else $encodingin=preg_match("/^<\?xml\b.*?\bencoding=(\"|')(.*?)(\"|')/",$data,$matches)?
			strtoupper($matches[2]):'UTF-8';
		$encodingquestion=0;
		if (!in_array($encodingin,$encodings_internal)) {
			if ($carpconf['haveiconv']||$carpconf['havemb']) {
				if ($fromfp) {
					while (!feof($fp)) if (($temp=CarpReadData($fp))!==false) $data.=$temp;
					fclose($fp);
					$fromfp=0;
				}
				$newencodingin=$transcodeout?'UTF-8':
					(isset($carpconf['encodingout']{0})?$carpconf['encodingout']:'ISO-8859-1');
				if (CarpTranscodeData($data,$encodingin,$newencodingin)) {
					$data=preg_replace("/(<\?xml\b.*?\bencoding=)(\"|').*?(\"|')/","\\1\\2$newencodingin\\3",$data);
					$encodingin=$newencodingin;
				} else CarpError('Encoding conversion ('.($carpconf['haveiconv']?'iconv':'mb_convert_encoding').') failed. Attempting to use original data...','iconv-failed',0);
			} else {
				$actualencoding=$encodingin;
				$encodingin='UTF-8';
				$encodingquestion=1;
			}
		}

		$xml_parser=xml_parser_create(strtoupper($encodingin));
		if (isset($carpconf['encodingout']{0})) {
			$rss_parser->encodingout=$transcodeout?'UTF-8':strtoupper($carpconf['encodingout']);
			xml_parser_set_option($xml_parser,XML_OPTION_TARGET_ENCODING,$rss_parser->encodingout);
		}

		xml_set_object($xml_parser,$rss_parser);
		xml_set_element_handler($xml_parser,"startElement","endElement");
		xml_set_character_data_handler($xml_parser,"characterData");

		$rss_parser->PrepTagPairs($carpconf['desctags']);
		$rss_parser->xmlbase=array(($url{strlen($url)-1}=='/')?$url:substr($url,0,strrpos($url,'/')+1));
		$carpconf['items-shown']=0;
		while (isset($data{0})||($fromfp&&!feof($fp))) {
			if (isset($data{0})||(($data=CarpReadData($fp))!==false)) {
				if ($carpconf['clean_input']) CarpCleanInput($data,$encodingin);
				if (!xml_parse($xml_parser,$data,$fromfp?feof($fp):1)) {
					CarpError("XML error: ".xml_error_string(xml_get_error_code($xml_parser))." at line ".xml_get_current_line_number($xml_parser).
						($encodingquestion?(". This error may be caused by the fact that PHP is unable to process this feed's encoding ($actualencoding), ".
							"and your server does not support the \"iconv\" or \"mb_convert_encoding\" function, ".
							"one of which is necessary to convert it to an encoding that PHP can process."):'').
							$rss_parser->XMLFormatError()
						,'xml-error');
					if ($fromfp) fclose($fp);
					xml_parser_free($xml_parser);
					unset($rss_parser);
					unset($carpconf['rssparser']);
					return;
				}
			}
			$data='';
		}
		if ($fromfp) fclose($fp);
		if ($rss_parser->displaychannel) {
			if (isset($rss_parser->channelborder[0]{0})) $rss_parser->DoEndChannel($rss_parser->top,$rss_parser->channelborder,$carpconf['bcb'],$carpconf['acb']);
			if (isset($rss_parser->channelaorder[0]{0})) $rss_parser->DoEndChannel($rss_parser->bottom,$rss_parser->channelaorder,$carpconf['bca'],$carpconf['aca']);
		}
		$data=($showit?($rss_parser->top.$carpconf['bitems']):('cb: :'.$rss_parser->top."\n".'ca: :'.$rss_parser->bottom."\n")).
			$rss_parser->body.
			($showit?($carpconf['aitems'].$rss_parser->bottom.$carpconf['poweredby']):'');
		if ($transcodeout) {
			if ($carpconf['haveiconv']||$carpconf['havemb']) {
				if (!CarpTranscodeData($data,'UTF-8',$carpconf['encodingout']))
					CarpError('Encoding conversion ('.($carpconf['haveiconv']?'iconv':'mb_convert_encoding').') failed. Outputting unconverted data.','iconv-failed',0);
			} else CarpError('Your server does not support the \"iconv\" or \"mb_convert_encoding\" function, ".
				"one of which is needed to convert CaRP\'s output to '.$carpconf['encodingout'].'. Outputting unconverted data.', 'no-iconv', 0);
		}

		if ($showit) {
			if ($carpconf['shownoitems']&&!$rss_parser->itemcount) CarpOutput($carpconf['noitems']);
			else CarpOutput($data);
			if (isset($rss_parser)&&!$rss_parser->itemcount) $rss_parser->XMLFormatError(1);
		}
		if ($cache) {
			if (($cfp=OpenCacheWrite())>0) {
				if ($carpconf['shownoitems']&&!$rss_parser->itemcount) CarpSaveCache($cfp,$carpconf['noitems']);
				else CarpSaveCache($cfp,$data);
				CloseCacheWrite($cfp);
			}
		}
		xml_parser_free($xml_parser);
		unset($carpconf['rssparser']);
	} else {
		CarpError('Can\'t open remote newsfeed ['.$carpconf['statuscode'].'].','feed-access-failed',0);
		if ($showit&&isset($carpconf['cachefile']{0})) CarpOutput(CarpGetCache($carpconf['cachefile']));
	}
}

return;
?>
