<!doctype html>
<html>
<head>
<meta charset="UTF-8">
<title>Email Success</title>
<link href="myvaccinelawyer.css" rel="stylesheet" type="text/css">
</head>

<body><div id="top_bar"></div>

<div id="logo_bar"><img src="images/logo_bar.png"/></div>
<div id="wrapper">
<p class="body">Your case evaluation form has been successfully submitted.  A vaccine attorney will be in contact after your submission has been reviewed.</p>
<p class="body"><a href="index.html">Click Here to Return to MyVaccineLawyer.com</a></p>
</div>
<!-- Google Code for Form Submission Conversion Page -->
<script type="text/javascript">
/* <![CDATA[ */
var google_conversion_id = 1001245317;
var google_conversion_language = "en";
var google_conversion_format = "3";
var google_conversion_color = "ffffff";
var google_conversion_label = "xrU5CNPY4AYQhZW33QM";
var google_conversion_value = 10;
var google_remarketing_only = false;
/* ]]> */
</script>
<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">
</script>
<noscript>
<div style="display:inline;">
<img height="1" width="1" style="border-style:none;" alt="" src="//www.googleadservices.com/pagead/conversion/1001245317/?value=10&amp;label=xrU5CNPY4AYQhZW33QM&amp;guid=ON&amp;script=0"/>
</div>
</noscript>

</body>
</html>