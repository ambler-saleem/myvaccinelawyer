<form action="thankyou.php" method="post">
Name: <input type="text" name="fullname"><br>
Email: <input type="text" name="email"><br>
Phone
City
State
Vaccine
Date of Vaccine
Comments: <textarea name="comments"></textarea><br />
Agree
<input type="submit" value="Send" />